import requests
from bs4 import BeautifulSoup

PHONES_URL = "https://www.jumia.com.ng/smartphones/"
ELECTRONICS_URL = "https://www.jumia.com.ng/electronics/"


def get_page_html(url):
    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    response = requests.get(url, headers=headers, timeout=15)
    response.raise_for_status()
    return response.text


def clean_price(price_text):
    cleaned = (
        price_text
        .replace("₦", "")
        .replace(",", "")
        .replace(" ", "")
        .strip()
    )
    if "." in cleaned:
        cleaned = cleaned.split(".")[0]
    return int(cleaned)


def is_price_within_range(price, min_price, max_price):
    return min_price <= price <= max_price


def get_phones(min_price, max_price):
    products = []

    html = get_page_html(PHONES_URL)
    soup = BeautifulSoup(html, "html.parser")

    product_cards = soup.find_all("article", class_="prd")

    for card in product_cards:
        name_tag = card.find("div", class_="name")
        price_tag = card.find("div", class_="prc")
        link_tag = card.find("a", class_="core")

        if name_tag and price_tag and link_tag:
            name = name_tag.text.strip()
            price = clean_price(price_tag.text)
            link = link_tag.get("href")

            if link.startswith("/"):
                link = "https://www.jumia.com.ng" + link

            if is_price_within_range(price, min_price, max_price):
                products.append({
                    "name": name,
                    "price": price,
                    "link": link
                })

    return products


def get_electronics(min_price, max_price):
    products = []

    html = get_page_html(ELECTRONICS_URL)
    soup = BeautifulSoup(html, "html.parser")

    product_cards = soup.find_all("article", class_="prd")

    for card in product_cards:
        name_tag = card.find("div", class_="name")
        price_tag = card.find("div", class_="prc")
        link_tag = card.find("a", class_="core")

        if name_tag and price_tag and link_tag:
            name = name_tag.text.strip()
            price = clean_price(price_tag.text)
            link = link_tag.get("href")

            if link.startswith("/"):
                link = "https://www.jumia.com.ng" + link

            if is_price_within_range(price, min_price, max_price):
                products.append({
                    "name": name,
                    "price": price,
                    "link": link
                })

    return products