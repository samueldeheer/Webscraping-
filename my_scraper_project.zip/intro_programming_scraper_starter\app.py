from flask import Flask, render_template, request
from scraper import get_phones, get_electronics

app = Flask(__name__)


@app.route("/")
def index():
    """Show the landing page with the search form."""
    return render_template("index.html")


@app.route("/products", methods=["POST"])
def products():
    """
    Receive the category and price range from the form,
    scrape the selected category, and display the results.
    """
    category = request.form.get("category")
    min_price = request.form.get("min_price", 0)
    max_price = request.form.get("max_price", 0)

    try:
        min_price = int(min_price)
        max_price = int(max_price)
    except ValueError:
        error = "Please enter valid numbers for minimum and maximum price."
        return render_template("index.html", error=error)

    if min_price < 0 or max_price < 0:
        error = "Prices cannot be negative."
        return render_template("index.html", error=error)

    if max_price < min_price:
        error = "Maximum price cannot be less than minimum price."
        return render_template("index.html", error=error)

    if category == "phones":
        products = get_phones(min_price, max_price)
        page_title = "Phones"
    elif category == "electronics":
        products = get_electronics(min_price, max_price)
        page_title = "Electronics"
    else:
        error = "Please select a valid category."
        return render_template("index.html", error=error)

    return render_template(
        "product_index.html",
        products=products,
        page_title=page_title,
        min_price=min_price,
        max_price=max_price
    )


if __name__ == "__main__":
    app.run(debug=True)
