# Introduction to Programming Capstone Starter Files

## Project: E-commerce Website Scraper

This starter project helps students build a simple Flask web app that scrapes product data from an e-commerce website and displays the results in a table.

Students should complete the TODO sections in `scraper.py`.

## What the app should do

1. Open the landing page.
2. Select a category: Phones or Electronics.
3. Enter minimum and maximum price.
4. Submit the form.
5. Scrape matching products from the selected category.
6. Show the product name, price, and product link in a table.

## Project Structure

```text
intro_programming_scraper_starter/
│
├── app.py
├── scraper.py
├── requirements.txt
├── README.md
│
├── templates/
│   ├── index.html
│   └── product_index.html
│
└── static/
    └── css/
        └── style.css
```

## Setup Instructions

### 1. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

Mac/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install the required packages

```bash
pip install -r requirements.txt
```

### 3. Run the application

```bash
python app.py
```

Open the address shown in your terminal, usually:

```text
http://127.0.0.1:5000
```

## Student Task

Open `scraper.py` and complete:

- `get_phones(min_price, max_price)`
- `get_electronics(min_price, max_price)`

Each function should return a list of dictionaries in this format:

```python
[
    {
        "name": "Product name here",
        "price": 150000,
        "link": "https://example.com/product-page"
    }
]
```

## Important Notes

- Do not copy and paste code you do not understand.
- Website HTML can change, so inspect the page carefully before writing your scraping code.
- Use the browser's "Inspect" tool to find the HTML tags/classes for product cards, names, prices, and links.
- This starter uses normal CSS only, not Bootstrap.
